# Lecteur Diaporama
Situation d'Apprentissage et d'Évaluation S2.01
- Développement d'une application
  
BUT Informatique 1ère année semestre 2 de l'IUT de Bayonne et du Pays Basque.

## Equipe projet
- Damageux Lucas
- Dirchaoui El Mahdi
- Laborde Romain
